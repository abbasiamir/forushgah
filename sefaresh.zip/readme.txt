type www.example.com/admin for adminstration

chang localhose by www.example.com

CREATE DATABASE db{
	
	CREATE TABLE payments{
		id INT,
		number INT,
		group INT,
		facilities VARCHAR(),
		price INT,
		istitr VARCHAR()
	}

	CREATE TABLE login{
		user VARCHAR(),
		password VARCHAR()
	}
}