<?php
 $url='localhost';
 $user="1019317";
 $pass="Am135839560";
 $db="1019317";
 ?>